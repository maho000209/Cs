﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2018_2_c샵_계산기만들기_강호진
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool Jieom_Flag = false;
        double Store_Sutja;
        string Store_Younsanja = "";
        bool Newsutja_Flag = false;
        bool younuse = false;
        public void num(int i)
        {
            if (Newsutja_Flag == true)
            {
                textBox1.Text = "";
                Newsutja_Flag = false;
            }
            if (textBox1.Text == "0" || textBox1.Text == "000")
                textBox1.Text = i.ToString();
            else
                textBox1.Text = textBox1.Text + i;
            younuse = false;


        }
        private void button2_Click(object sender, EventArgs e)
        {
            num(2);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            num(1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            num(3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            num(4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            num(5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            num(6);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            num(7);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            num(8);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            num(9);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (Jieom_Flag == false && textBox1.Text != "")
            {
                textBox1.Text = textBox1.Text + ".";
                Jieom_Flag = true;
            }
            else if (textBox1.Text == "")
            {
                textBox1.Text = textBox1.Text + "0.";
                Jieom_Flag = true;

            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" || textBox1.Text == "000" || textBox1.Text == "")
                textBox1.Text = "0";
            else
                textBox1.Text = textBox1.Text + "000";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0" || textBox1.Text == "000")
                textBox1.Text = "0";
            else
                textBox1.Text = textBox1.Text + "0";

        }

        private void button13_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            Jieom_Flag = false;
            Store_Sutja = 0;
            Store_Younsanja = "";
            younuse = false;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "0")
            {
                if (textBox1.Text.Substring(textBox1.TextLength - 1) == ".")
                    Jieom_Flag = false;
                textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
            }
            if (textBox1.Text == "")
                textBox1.Text = "0";
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (Store_Younsanja.Equals("") || younuse == true)
            {
                Store_Sutja = double.Parse(textBox1.Text);
                Store_Younsanja = "+";
            }
                else if (younuse == false)
                {
                    iOperation(); younuse = true;
                    Store_Sutja = double.Parse(textBox1.Text);
                    Store_Younsanja = "+";
                    younuse = true;
                }
            
            Newsutja_Flag = true;
            Jieom_Flag = false;
        }
        public void iOperation()
        {
            if (Store_Younsanja == "+")
                textBox1.Text = (Store_Sutja + double.Parse(textBox1.Text)).ToString();
            else if (Store_Younsanja == "-")
                textBox1.Text = (Store_Sutja - double.Parse(textBox1.Text)).ToString();
            else if (Store_Younsanja == "*")
                textBox1.Text = (Store_Sutja * double.Parse(textBox1.Text)).ToString();
            else if (Store_Younsanja == "/")
                textBox1.Text = (Store_Sutja / double.Parse(textBox1.Text)).ToString();
            else if (Store_Younsanja == "=")
                textBox1.Text = double.Parse(textBox1.Text).ToString();
            younuse = true;
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (Store_Younsanja == "" || younuse == true)
            {
                Store_Sutja = double.Parse(textBox1.Text);
                Store_Younsanja = "-";
            }
            else if(younuse == false)
            {
                iOperation();
                Store_Sutja = double.Parse(textBox1.Text);
                Store_Younsanja = "-";
                younuse = true;

            }
            Newsutja_Flag = true;
            Jieom_Flag = false;


        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (Store_Younsanja == "" || younuse == true)
            {
                Store_Sutja = double.Parse(textBox1.Text);
                Store_Younsanja = "*";
            }

            else if (younuse == false)
            {
                iOperation();
                Store_Sutja = double.Parse(textBox1.Text);
                Store_Younsanja = "*";
                younuse = true;

            }
            Newsutja_Flag = true;
            Jieom_Flag = false;


        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (Store_Younsanja == "" || younuse == true)
            {
                Store_Sutja = double.Parse(textBox1.Text);
                Store_Younsanja = "/";
            }
            else if (younuse == false)
            {
                iOperation();
                Store_Sutja = double.Parse(textBox1.Text);
                Store_Younsanja = "/";
                younuse = true;

            }
            Newsutja_Flag = true;
            Jieom_Flag = false;


        }

        private void button19_Click(object sender, EventArgs e)
        {
            iOperation();
            Store_Younsanja = "";
            Store_Sutja = 0;
            Jieom_Flag = false;
            Newsutja_Flag = true;
        }
    }
}
